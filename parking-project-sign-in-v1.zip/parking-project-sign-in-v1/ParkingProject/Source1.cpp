#include "Header2.h"

Car::Car(string license, string col, string ty)
{
	licensePlate = license;
	color = col;
	type = ty;
}

Car::Car()
{

}

bool Car::matches(string l)
{
	return (l == licensePlate) ? true : false;
}

string Car::getLicensePlate()
{
	return licensePlate;
}