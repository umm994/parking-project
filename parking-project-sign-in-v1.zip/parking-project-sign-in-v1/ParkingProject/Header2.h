#ifndef CAR_H
#define CAR_H

#include "string"

using namespace std;

class Car {
public:
	Car(string, string, string);
	~Car();
	string getLicensePlate();

private:
	string licensePlate;
	string color;
	string type;
};
